package es.fdi.eventsoft.negocio.comandos.imp.valoraciones;

import es.fdi.eventsoft.negocio.comandos.Comando;
import es.fdi.eventsoft.negocio.comandos.Contexto;

/**
 * Created by Rodrigo de Miguel on 09/05/2017.
 */
public class ComandoCrearValoracion implements Comando {

    public Contexto execute(Object datos){
        //TODO
        Contexto contex = null;



        return contex;
    }

}
